// test/sanity.test.ts
describe("sanity", () => {
  it("Karma + Jasmine está funcionando", () => {
    expect(2 + 2).toBe(4);
  });
});
