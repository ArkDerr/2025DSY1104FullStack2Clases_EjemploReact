// karma.conf.js
module.exports = function (config) {
  config.set({
    basePath: "",
    frameworks: ["jasmine"],

    files: [{ pattern: "src/**/*.spec.{js,jsx}", watched: false }],
    exclude: ["src/**/*.test.*"],

    preprocessors: {
      // Specs y código pasan por esbuild
      "src/**/*.spec.{js,jsx}": ["esbuild"],
      "src/**/*.{js,jsx}": ["esbuild", "coverage"], // instrumenta para cobertura
    },

    esbuild: {
      target: "es2020",
      sourcemap: "inline",
      jsx: "automatic",
      loader: {
        ".js": "jsx",
        ".jsx": "jsx",
        ".png": "dataurl",
        ".jpg": "dataurl",
        ".jpeg": "dataurl",
        ".webp": "dataurl",
        ".svg": "dataurl",
        ".css": "css",
      },
    },

    // 🔇 Cambiamos el reporter a 'dots' para evitar el mensaje del reload
    reporters: ["dots", "coverage"],

    coverageReporter: {
      dir: "coverage",
      reporters: [{ type: "html" }, { type: "text-summary" }],
      includeAllSources: true,
      instrumenterOptions: { istanbul: { noCompact: true } },
    },

    // Elige navegador
    // browsers: ['ChromeHeadless'],
    browsers: ["Opera"], // si prefieres Opera (requiere karma-opera-launcher)

    singleRun: true,
    autoWatch: false,
    client: {
      clearContext: true, // limpia el iframe del reporter (menos ruido)
    },
    browserNoActivityTimeout: 60000,
  });
};
