// src/pages/Home.spec.js
import React from "react";
import ReactDOM from "react-dom/client";
import { flushSync } from "react-dom";
import Home from "./Home";

const tick = () => new Promise((r) => setTimeout(r, 0));

describe("Componente Home", () => {
  let container, root;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
    root = ReactDOM.createRoot(container);
  });

  afterEach(() => {
    root.unmount?.();
    document.body.removeChild(container);
    container = null;
  });

  it("renderiza el título principal", async () => {
    flushSync(() => root.render(<Home />));
    await tick();
    const titulo = container.querySelector("h1.pastel-navbar");
    expect(titulo).not.toBeNull();
    expect(titulo.textContent).toBe("Nuestros Productos");
  });

  it("renderiza 3 imágenes en el carrusel", async () => {
    flushSync(() => root.render(<Home />));
    await tick();
    const imgs = container.querySelectorAll(".carousel-item img");
    expect(imgs.length).toBe(3);
  });

  it("renderiza todas las cards de productos", async () => {
    flushSync(() => root.render(<Home />));
    await tick();
    const cards = container.querySelectorAll(".card");
    expect(cards.length).toBe(4);
  });

  it('cada producto tiene un botón "Añadir"', async () => {
    flushSync(() => root.render(<Home />));
    await tick();
    const botones = container.querySelectorAll(".card button");
    expect(botones.length).toBe(4);
    botones.forEach((btn) => expect(btn.textContent).toBe("Añadir"));
  });
});
