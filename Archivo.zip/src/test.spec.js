describe('Demo test', () => {
  it('suma básica', () => {
    expect(2 + 2).toBe(4);
  });
});
